# BD Müzik

YouTube'dan müzik ve video indiren, çalma listesi oluşturan ve arka planda müzik çalan Android uygulaması.
(Kotlin + Jetpack Compose, Media3, Room, WorkManager, NewPipeExtractor)

## Özellikler
- **Ara**: YouTube Müzik şarkı araması veya normal video araması (üstteki Müzik / Video seçici)
- **İndir**: Müzik olarak (m4a ses) veya video olarak (mp4, 720p'ye kadar). İlerleme halkası ve bildirim
- **Kitaplık**: İndirilenleri çevrimdışı çal, karıştır, sil
- **Çalma listeleri**: Oluştur, şarkı ekle/çıkar, sil. İndirilmemiş şarkıları da listeye ekleyebilirsin (akıştan çalar)
- **Arka planda çalma**: Bildirimde ve kilit ekranında kontroller, Bluetooth/kulaklık tuşları, karıştır / tekrarla
- Tam ekran oynatıcı ve alt mini oynatıcı

## Derleme
1. Android Studio'yu (Ladybug veya üstü) aç, **Open** ile bu klasörü seç.
2. Gradle senkronizasyonunu bekle (JDK 17 gerekir; Android Studio ile gelir).
3. Telefonu USB hata ayıklama ile bağla ve **Run** de. APK için: Build > Build APK(s).

Gereksinimler: Android 8.0 (API 26) ve üzeri.

## İndirilen dosyalar
`Android/data/com.bd.muzik/files/Muzik` ve `.../Videolar` klasörlerine kaydedilir.
Uygulama silinirse bu dosyalar da silinir.

## Bakım notu
YouTube arama/akış çözümleme `NewPipeExtractor` kütüphanesine dayanır (`app/build.gradle.kts`).
YouTube sık sık değişiklik yaptığı için bir gün arama ya da indirme çalışmayı bırakırsa kütüphanenin
sürümünü güncelle: https://jitpack.io/#TeamNewPipe/NewPipeExtractor

## Yasal uyarı
YouTube'dan içerik indirmek YouTube Hizmet Şartları'na aykırı olabilir ve telif hakkıyla
korunan içeriklerin izinsiz kopyalanması bazı ülkelerde suçtur. Uygulamayı yalnızca indirme
hakkına sahip olduğun içerikler için, kişisel kullanımda kullan.
