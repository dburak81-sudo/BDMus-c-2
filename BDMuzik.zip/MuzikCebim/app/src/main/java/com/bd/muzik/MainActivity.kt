package com.bd.muzik

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bd.muzik.data.SongEntity
import com.bd.muzik.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { BdTheme { BdApp() } }
    }
}

@Composable
fun BdApp(vm: MainVm = viewModel()) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var fullPlayer by remember { mutableStateOf(false) }
    var addTarget by remember { mutableStateOf<SongEntity?>(null) }
    val snack = remember { SnackbarHostState() }
    val playlists by vm.playlists.collectAsState()

    // Android 13+ bildirim izni (çalma ve indirme bildirimleri için)
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(vm.message) {
        vm.message?.let { snack.showSnackbar(it); vm.message = null }
    }

    Scaffold(
        containerColor = Bg,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            Column {
                MiniPlayer(vm) { fullPlayer = true }
                NavigationBar(containerColor = Card) {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Rounded.Search, null) }, label = { Text("Ara") },
                        colors = navColors()
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Rounded.LibraryMusic, null) }, label = { Text("Kitaplık") },
                        colors = navColors()
                    )
                    NavigationBarItem(
                        selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.AutoMirrored.Rounded.QueueMusic, null) }, label = { Text("Listeler") },
                        colors = navColors()
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            when (tab) {
                0 -> SearchScreen(vm) { addTarget = it }
                1 -> LibraryScreen(vm) { addTarget = it }
                else -> PlaylistsScreen(vm) { addTarget = it }
            }
        }
    }

    if (fullPlayer) FullPlayer(vm) { fullPlayer = false }

    addTarget?.let { song ->
        AddToPlaylistDialog(
            playlists = playlists,
            onDismiss = { addTarget = null },
            onPick = { vm.addToPlaylist(it.id, song); addTarget = null },
            onNew = { name -> vm.createPlaylist(name, song); addTarget = null }
        )
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Accent,
    selectedTextColor = Accent,
    indicatorColor = androidx.compose.ui.graphics.Color(0xFF3A1A1A)
)
