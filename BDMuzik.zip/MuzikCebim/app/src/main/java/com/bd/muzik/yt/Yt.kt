package com.bd.muzik.yt

import com.bd.muzik.data.SongEntity
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

const val USER_AGENT =
    "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0"

/** NewPipeExtractor için OkHttp tabanlı indirici. */
private class NpDownloader(private val client: OkHttpClient) : Downloader() {
    override fun execute(request: Request): Response {
        val data = request.dataToSend()
        val method = request.httpMethod()
        val body = when {
            data != null -> data.toRequestBody(null, 0, data.size)
            method == "POST" || method == "PUT" -> ByteArray(0).toRequestBody()
            else -> null
        }
        val builder = okhttp3.Request.Builder()
            .method(method, body)
            .url(request.url())
            .addHeader("User-Agent", USER_AGENT)
        request.headers().forEach { (name, values) ->
            builder.removeHeader(name)
            values.forEach { builder.addHeader(name, it) }
        }
        client.newCall(builder.build()).execute().use { resp ->
            if (resp.code == 429) throw ReCaptchaException("reCaptcha istendi", request.url())
            return Response(
                resp.code,
                resp.message,
                resp.headers.toMultimap(),
                resp.body?.string(),
                resp.request.url.toString()
            )
        }
    }
}

data class Resolved(val url: String, val ext: String)

/** YouTube ile ilgili tüm ağ işleri. Fonksiyonlar bloklayıcıdır; IO thread'inde çağır. */
object Yt {
    val client: OkHttpClient = OkHttpClient.Builder()
        .readTimeout(30, TimeUnit.SECONDS)
        .connectTimeout(20, TimeUnit.SECONDS)
        .build()

    @Volatile private var ready = false

    fun init() {
        if (ready) return
        NewPipe.init(NpDownloader(client), Localization("tr", "TR"), ContentCountry("TR"))
        ready = true
    }

    private fun watchUrl(id: String) = "https://www.youtube.com/watch?v=$id"

    private fun idOf(url: String): String =
        url.substringAfter("v=", "").substringBefore("&").ifEmpty { url.substringAfterLast("/") }

    /** videos=false -> YouTube Music "şarkılar" filtresi, true -> normal videolar */
    fun search(query: String, videos: Boolean): List<SongEntity> {
        init()
        val filter = if (videos) YoutubeSearchQueryHandlerFactory.VIDEOS
        else YoutubeSearchQueryHandlerFactory.MUSIC_SONGS
        val extractor = ServiceList.YouTube.getSearchExtractor(query, listOf(filter), "")
        extractor.fetchPage()
        return extractor.initialPage.items
            .filterIsInstance<StreamInfoItem>()
            .map {
                SongEntity(
                    videoId = idOf(it.url),
                    title = it.name,
                    artist = it.uploaderName ?: "",
                    thumb = it.thumbnails.firstOrNull()?.url ?: "",
                    durationSec = it.duration
                )
            }
    }

    // --- Akış URL'leri (süreleri ~6 saat) ---
    private val cache = ConcurrentHashMap<String, Pair<Long, Resolved>>()

    private fun info(id: String): StreamInfo {
        init()
        return StreamInfo.getInfo(ServiceList.YouTube, watchUrl(id))
    }

    fun audio(id: String): Resolved {
        val key = "a:$id"
        cache[key]?.let { (t, r) -> if (System.currentTimeMillis() - t < 4 * 3600_000L) return r }
        val streams = info(id).audioStreams
            .filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.isUrl }
        val pool = streams.filter { it.format == MediaFormat.M4A }.ifEmpty { streams }
        val best = pool.maxByOrNull { it.averageBitrate } ?: error("Ses akışı bulunamadı")
        return Resolved(best.content, best.format?.suffix ?: "m4a")
            .also { cache[key] = System.currentTimeMillis() to it }
    }

    /** Ses+görüntü birlikte gelen (muxed) en yüksek kalite, 720p'ye kadar. */
    fun video(id: String): Resolved {
        val streams = info(id).videoStreams
            .filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.isUrl }
        val best = streams.maxByOrNull { it.height } ?: error("Video akışı bulunamadı")
        return Resolved(best.content, best.format?.suffix ?: "mp4")
    }
}
