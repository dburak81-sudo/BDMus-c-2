package com.bd.muzik.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.bd.muzik.data.PlaylistWithCount
import com.bd.muzik.data.SongEntity
import com.bd.muzik.fmt

@Composable
fun Thumb(url: Any?, size: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier) {
    AsyncImage(
        model = url,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(8.dp))
            .background(Card)
    )
}

/**
 * Şarkı satırı.
 * @param progress null: indirme yok, 0..100: indiriliyor
 */
@Composable
fun SongRow(
    song: SongEntity,
    progress: Int?,
    onClick: () -> Unit,
    onDownloadAudio: () -> Unit,
    onDownloadVideo: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onDelete: (() -> Unit)? = null,
    onRemoveFromPlaylist: (() -> Unit)? = null
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(song.thumb, 56.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge)
            Text(
                listOf(song.artist, fmt(song.durationSec)).filter { it.isNotBlank() }.joinToString(" • "),
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        }
        when {
            progress != null -> CircularProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.size(24.dp),
                strokeWidth = 2.5.dp,
                color = Accent
            )
            song.isDownloaded -> Icon(Icons.Rounded.DownloadDone, "İndirildi", tint = Accent)
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Menü") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (song.audioPath == null) DropdownMenuItem(
                    text = { Text("Müzik olarak indir") },
                    leadingIcon = { Icon(Icons.Rounded.MusicNote, null) },
                    onClick = { menu = false; onDownloadAudio() })
                if (song.videoPath == null) DropdownMenuItem(
                    text = { Text("Video olarak indir") },
                    leadingIcon = { Icon(Icons.Rounded.Videocam, null) },
                    onClick = { menu = false; onDownloadVideo() })
                DropdownMenuItem(
                    text = { Text("Çalma listesine ekle") },
                    leadingIcon = { Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, null) },
                    onClick = { menu = false; onAddToPlaylist() })
                if (onRemoveFromPlaylist != null) DropdownMenuItem(
                    text = { Text("Listeden çıkar") },
                    leadingIcon = { Icon(Icons.Rounded.RemoveCircleOutline, null) },
                    onClick = { menu = false; onRemoveFromPlaylist() })
                if (song.isDownloaded && onDelete != null) DropdownMenuItem(
                    text = { Text("İndirmeyi sil") },
                    leadingIcon = { Icon(Icons.Rounded.Delete, null) },
                    onClick = { menu = false; onDelete() })
            }
        }
    }
}

@Composable
fun PlayAllBar(onPlay: () -> Unit, onShuffle: () -> Unit) {
    Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
            Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Oynat")
        }
        OutlinedButton(onClick = onShuffle) {
            Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Karıştır")
        }
    }
}

@Composable
fun NameDialog(title: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                singleLine = true, label = { Text("Liste adı") }
            )
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onOk(name.trim()) }) { Text("Oluştur") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } }
    )
}

@Composable
fun AddToPlaylistDialog(
    playlists: List<PlaylistWithCount>,
    onDismiss: () -> Unit,
    onPick: (PlaylistWithCount) -> Unit,
    onNew: (String) -> Unit
) {
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        NameDialog("Yeni çalma listesi", onDismiss = { creating = false }, onOk = onNew)
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Çalma listesine ekle") },
        text = {
            Column {
                TextButton(onClick = { creating = true }) {
                    Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("Yeni liste oluştur")
                }
                playlists.forEach { p ->
                    Text(
                        "${p.name}  (${p.count})",
                        Modifier.fillMaxWidth().clickable { onPick(p) }.padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Kapat") } }
    )
}
