package com.bd.muzik.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.bd.muzik.MainVm
import com.bd.muzik.data.PlaylistWithCount
import com.bd.muzik.data.SongEntity

@Composable
fun SearchScreen(vm: MainVm, onAdd: (SongEntity) -> Unit) {
    val focus: FocusManager = LocalFocusManager.current
    val local by vm.downloaded.collectAsState()
    val prog by vm.progress.collectAsState()
    val byId = remember(local) { local.associateBy { it.videoId } }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = vm.query,
            onValueChange = { vm.query = it },
            modifier = Modifier.fillMaxWidth().padding(16.dp, 12.dp, 16.dp, 4.dp),
            singleLine = true,
            placeholder = { Text(if (vm.videoMode) "YouTube'da video ara" else "Şarkı, sanatçı veya albüm ara") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = {
                if (vm.query.isNotEmpty()) IconButton(onClick = { vm.query = "" }) { Icon(Icons.Rounded.Close, "Temizle") }
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { focus.clearFocus(); vm.search() })
        )
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !vm.videoMode, onClick = { vm.videoMode = false },
                label = { Text("Müzik") }, leadingIcon = { Icon(Icons.Rounded.MusicNote, null, Modifier.size(18.dp)) })
            FilterChip(selected = vm.videoMode, onClick = { vm.videoMode = true },
                label = { Text("Video") }, leadingIcon = { Icon(Icons.Rounded.Videocam, null, Modifier.size(18.dp)) })
        }
        if (vm.searching) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Accent)

        if (vm.results.isEmpty() && !vm.searching) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Aramaya başla ve indirmek istediğini seç",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(vm.results, key = { i, s -> "${s.videoId}-$i" }) { i, s ->
                val song = byId[s.videoId] ?: s
                SongRow(
                    song = song,
                    progress = prog[s.videoId],
                    onClick = { vm.play(vm.results, i) },
                    onDownloadAudio = { vm.download(song, false) },
                    onDownloadVideo = { vm.download(song, true) },
                    onAddToPlaylist = { onAdd(song) }
                )
            }
        }
    }
}

@Composable
fun LibraryScreen(vm: MainVm, onAdd: (SongEntity) -> Unit) {
    val songs by vm.downloaded.collectAsState()
    val prog by vm.progress.collectAsState()
    Column(Modifier.fillMaxSize()) {
        Text("İndirilenler", style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 0.dp))
        if (songs.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Henüz indirilmiş müzik yok", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            return
        }
        PlayAllBar(onPlay = { vm.play(songs, 0) }, onShuffle = { vm.play(songs, (songs.indices).random(), true) })
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(songs, key = { _, s -> s.videoId }) { i, s ->
                SongRow(
                    song = s, progress = prog[s.videoId],
                    onClick = { vm.play(songs, i) },
                    onDownloadAudio = { vm.download(s, false) },
                    onDownloadVideo = { vm.download(s, true) },
                    onAddToPlaylist = { onAdd(s) },
                    onDelete = { vm.deleteDownload(s) }
                )
            }
        }
    }
}

@Composable
fun PlaylistsScreen(vm: MainVm, onAdd: (SongEntity) -> Unit) {
    val lists by vm.playlists.collectAsState()
    var open by remember { mutableStateOf<PlaylistWithCount?>(null) }
    var creating by remember { mutableStateOf(false) }

    open?.let { p ->
        // Silinmiş/yeniden adlandırılmış listeyi güncel hâliyle göster
        val live = lists.firstOrNull { it.id == p.id }
        if (live != null) {
            PlaylistDetail(vm, live, onBack = { open = null }, onAdd = onAdd)
            return
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Çalma Listeleri", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            FilledTonalButton(onClick = { creating = true }) {
                Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("Yeni")
            }
        }
        if (lists.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("İlk çalma listeni oluştur", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(lists, key = { it.id }) { p ->
                Row(
                    Modifier.fillMaxWidth().clickable { open = p }.padding(16.dp, 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.AutoMirrored.Rounded.QueueMusic, null, tint = Accent, modifier = Modifier.size(40.dp))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(p.name, style = MaterialTheme.typography.bodyLarge)
                        Text("${p.count} şarkı", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
    if (creating) NameDialog("Yeni çalma listesi", onDismiss = { creating = false },
        onOk = { vm.createPlaylist(it); creating = false })
}

@Composable
private fun PlaylistDetail(
    vm: MainVm, p: PlaylistWithCount, onBack: () -> Unit, onAdd: (SongEntity) -> Unit
) {
    BackHandler(onBack = onBack)
    val songs by vm.playlistSongs(p.id).collectAsState(emptyList())
    val local by vm.downloaded.collectAsState()
    val prog by vm.progress.collectAsState()
    val byId = remember(local) { local.associateBy { it.videoId } }
    var confirm by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(4.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Geri") }
            Text(p.name, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            IconButton(onClick = { confirm = true }) { Icon(Icons.Rounded.Delete, "Listeyi sil") }
        }
        if (songs.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Bu listede şarkı yok.\nAramadan veya Kitaplık'tan ekleyebilirsin.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            PlayAllBar(onPlay = { vm.play(songs, 0) }, onShuffle = { vm.play(songs, songs.indices.random(), true) })
            LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(songs, key = { _, s -> s.videoId }) { i, s ->
                    val song = byId[s.videoId] ?: s
                    SongRow(
                        song = song, progress = prog[s.videoId],
                        onClick = { vm.play(songs.map { byId[it.videoId] ?: it }, i) },
                        onDownloadAudio = { vm.download(song, false) },
                        onDownloadVideo = { vm.download(song, true) },
                        onAddToPlaylist = { onAdd(song) },
                        onDelete = { vm.deleteDownload(song) },
                        onRemoveFromPlaylist = { vm.removeFromPlaylist(p.id, song) }
                    )
                }
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Liste silinsin mi?") },
        text = { Text("\"${p.name}\" silinecek. İndirilen şarkılar silinmez.") },
        confirmButton = { TextButton(onClick = { vm.deletePlaylist(p.id); confirm = false; onBack() }) { Text("Sil") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Vazgeç") } }
    )
}
