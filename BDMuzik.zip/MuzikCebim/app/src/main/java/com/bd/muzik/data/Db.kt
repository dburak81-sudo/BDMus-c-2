package com.bd.muzik.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "songs")
data class SongEntity(
    @PrimaryKey val videoId: String,
    val title: String,
    val artist: String,
    val thumb: String,
    val durationSec: Long,
    val audioPath: String? = null,
    val videoPath: String? = null
) {
    val isDownloaded get() = audioPath != null || videoPath != null
}

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Entity(tableName = "playlist_songs", primaryKeys = ["playlistId", "videoId"])
data class PlaylistSong(
    val playlistId: Long,
    val videoId: String,
    val position: Long = System.currentTimeMillis()
)

data class PlaylistWithCount(
    val id: Long,
    val name: String,
    val count: Int
)

@Dao
interface MusicDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSong(song: SongEntity)

    @Query("UPDATE songs SET audioPath = :path WHERE videoId = :id")
    suspend fun setAudioPath(id: String, path: String?)

    @Query("UPDATE songs SET videoPath = :path WHERE videoId = :id")
    suspend fun setVideoPath(id: String, path: String?)

    @Query("SELECT * FROM songs WHERE videoId = :id")
    suspend fun song(id: String): SongEntity?

    @Query("SELECT * FROM songs WHERE audioPath IS NOT NULL OR videoPath IS NOT NULL ORDER BY title")
    fun downloaded(): Flow<List<SongEntity>>

    @Query(
        "SELECT p.id AS id, p.name AS name, " +
            "(SELECT COUNT(*) FROM playlist_songs ps WHERE ps.playlistId = p.id) AS count " +
            "FROM playlists p ORDER BY p.id DESC"
    )
    fun playlists(): Flow<List<PlaylistWithCount>>

    @Query(
        "SELECT s.* FROM songs s JOIN playlist_songs ps ON ps.videoId = s.videoId " +
            "WHERE ps.playlistId = :playlistId ORDER BY ps.position"
    )
    fun playlistSongs(playlistId: Long): Flow<List<SongEntity>>

    @Insert
    suspend fun insertPlaylist(p: PlaylistEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addToPlaylist(ps: PlaylistSong)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :pid AND videoId = :vid")
    suspend fun removeFromPlaylist(pid: Long, vid: String)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :pid")
    suspend fun clearPlaylist(pid: Long)

    @Query("DELETE FROM playlists WHERE id = :pid")
    suspend fun deletePlaylistRow(pid: Long)

    @Transaction
    suspend fun deletePlaylist(pid: Long) {
        clearPlaylist(pid)
        deletePlaylistRow(pid)
    }
}

@Database(
    entities = [SongEntity::class, PlaylistEntity::class, PlaylistSong::class],
    version = 1,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): MusicDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(ctx: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "bdmuzik.db")
                .build().also { instance = it }
        }
    }
}
