package com.bd.muzik

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.work.*
import com.bd.muzik.data.*
import com.bd.muzik.yt.Yt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

fun fmt(sec: Long): String {
    if (sec <= 0) return "0:00"
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

/** İndirilmişse yerel dosyadan, değilse akıştan çalınacak MediaItem. */
fun SongEntity.toMediaItem(): MediaItem {
    val uri = when {
        audioPath != null && File(audioPath).exists() -> Uri.fromFile(File(audioPath))
        videoPath != null && File(videoPath).exists() -> Uri.fromFile(File(videoPath))
        else -> Uri.parse("ytid:$videoId")
    }
    val meta = MediaMetadata.Builder()
        .setTitle(title)
        .setArtist(artist)
        .apply { if (thumb.isNotEmpty()) setArtworkUri(Uri.parse(thumb)) }
        .build()
    return MediaItem.Builder().setMediaId(videoId).setUri(uri).setMediaMetadata(meta).build()
}

class MainVm(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    private val wm = WorkManager.getInstance(app)

    // ---- Arama ----
    var query by mutableStateOf("")
    var videoMode by mutableStateOf(false)
    var results by mutableStateOf<List<SongEntity>>(emptyList())
    var searching by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)

    fun search() {
        val q = query.trim()
        if (q.isEmpty()) return
        viewModelScope.launch {
            searching = true
            try {
                results = withContext(Dispatchers.IO) { Yt.search(q, videoMode) }
                if (results.isEmpty()) message = "Sonuç bulunamadı"
            } catch (e: Exception) {
                message = "Arama başarısız: ${e.message ?: "bağlantıyı kontrol et"}"
            } finally {
                searching = false
            }
        }
    }

    // ---- Kitaplık ----
    val downloaded = dao.downloaded()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val playlists = dao.playlists()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun playlistSongs(id: Long) = dao.playlistSongs(id)

    /** videoId -> yüzde (devam eden / sıradaki indirmeler) */
    val progress: StateFlow<Map<String, Int>> = wm.getWorkInfosByTagFlow(DownloadWorker.TAG)
        .map { list ->
            val out = HashMap<String, Int>()
            for (w in list) {
                if (w.state != WorkInfo.State.RUNNING && w.state != WorkInfo.State.ENQUEUED) continue
                val id = w.tags.firstOrNull { it.startsWith("id:") }?.removePrefix("id:") ?: continue
                out[id] = w.progress.getInt(DownloadWorker.KEY_PROGRESS, 0)
            }
            out
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    init {
        // Başarısız indirmeleri bir kez bildir (uygulama açılışındaki eski kayıtları atla)
        viewModelScope.launch {
            val seen = HashSet<java.util.UUID>()
            var first = true
            wm.getWorkInfosByTagFlow(DownloadWorker.TAG).collect { list ->
                val failed = list.filter { it.state == WorkInfo.State.FAILED }
                for (w in failed) {
                    if (seen.add(w.id) && !first) {
                        message = "İndirme başarısız: " + (w.outputData.getString("err") ?: "bilinmeyen hata")
                    }
                }
                first = false
            }
        }
    }

    fun download(song: SongEntity, video: Boolean) {
        viewModelScope.launch {
            dao.insertSong(song)
            val req = OneTimeWorkRequestBuilder<DownloadWorker>()
                .setInputData(
                    workDataOf(
                        DownloadWorker.KEY_ID to song.videoId,
                        DownloadWorker.KEY_TITLE to song.title,
                        DownloadWorker.KEY_VIDEO to video
                    )
                )
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .addTag(DownloadWorker.TAG)
                .addTag("id:${song.videoId}")
                .build()
            wm.enqueueUniqueWork(
                "dl-${song.videoId}-${if (video) "v" else "a"}",
                ExistingWorkPolicy.KEEP,
                req
            )
            message = "İndirme başladı: ${song.title}"
        }
    }

    fun deleteDownload(song: SongEntity) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                song.audioPath?.let { File(it).delete() }
                song.videoPath?.let { File(it).delete() }
            }
            dao.setAudioPath(song.videoId, null)
            dao.setVideoPath(song.videoId, null)
        }
    }

    // ---- Çalma listeleri ----
    fun createPlaylist(name: String, thenAdd: SongEntity? = null) {
        viewModelScope.launch {
            val id = dao.insertPlaylist(PlaylistEntity(name = name.trim()))
            if (thenAdd != null) addToPlaylist(id, thenAdd)
        }
    }

    fun addToPlaylist(pid: Long, song: SongEntity) {
        viewModelScope.launch {
            dao.insertSong(song)
            dao.addToPlaylist(PlaylistSong(pid, song.videoId))
            message = "Listeye eklendi"
        }
    }

    fun removeFromPlaylist(pid: Long, song: SongEntity) {
        viewModelScope.launch { dao.removeFromPlaylist(pid, song.videoId) }
    }

    fun deletePlaylist(pid: Long) {
        viewModelScope.launch { dao.deletePlaylist(pid) }
    }

    // ---- Oynatıcı ----
    var controller by mutableStateOf<MediaController?>(null)
    var isPlaying by mutableStateOf(false)
    var current by mutableStateOf<MediaItem?>(null)
    var shuffle by mutableStateOf(false)
    var repeatMode by mutableStateOf(Player.REPEAT_MODE_OFF)

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { this@MainVm.isPlaying = isPlaying }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { current = mediaItem }
        override fun onShuffleModeEnabledChanged(enabled: Boolean) { shuffle = enabled }
        override fun onRepeatModeChanged(mode: Int) { repeatMode = mode }
        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            message = "Oynatma hatası: ${error.message}"
            controller?.run { if (hasNextMediaItem()) { seekToNextMediaItem(); prepare(); play() } }
        }
    }

    init {
        val ctx = getApplication<Application>()
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            val c = future.get()
            c.addListener(listener)
            controller = c
            isPlaying = c.isPlaying
            current = c.currentMediaItem
            shuffle = c.shuffleModeEnabled
            repeatMode = c.repeatMode
        }, ContextCompat.getMainExecutor(ctx))
    }

    fun play(list: List<SongEntity>, index: Int, shuffled: Boolean = false) {
        val c = controller ?: return
        if (list.isEmpty()) return
        c.shuffleModeEnabled = shuffled
        c.setMediaItems(list.map { it.toMediaItem() }, index.coerceIn(0, list.lastIndex), 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun previous() {
        controller?.let { if (it.currentPosition > 3000) it.seekTo(0) else it.seekToPreviousMediaItem() }
    }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
