package com.bd.muzik

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.bd.muzik.data.AppDb
import com.bd.muzik.yt.USER_AGENT
import com.bd.muzik.yt.Yt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File

class DownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun getForegroundInfo(): ForegroundInfo = foreground(inputData.getString(KEY_TITLE) ?: "")

    private fun foreground(title: String): ForegroundInfo {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "İndirmeler", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("BD Müzik")
            .setContentText("İndiriliyor: $title")
            .setOngoing(true)
            .build()
        val id = 1000 + (inputData.getString(KEY_ID).hashCode() and 0xFFF)
        return if (Build.VERSION.SDK_INT >= 29)
            ForegroundInfo(id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(id, n)
    }

    override suspend fun doWork(): Result {
        val id = inputData.getString(KEY_ID) ?: return Result.failure()
        val title = inputData.getString(KEY_TITLE) ?: id
        val video = inputData.getBoolean(KEY_VIDEO, false)
        return try {
            runCatching { setForeground(foreground(title)) } // bildirim açılamazsa yine de indir
            val resolved = withContext(Dispatchers.IO) { if (video) Yt.video(id) else Yt.audio(id) }
            val dir = File(
                applicationContext.getExternalFilesDir(null),
                if (video) "Videolar" else "Muzik"
            ).apply { mkdirs() }
            val safe = title.replace(Regex("[^\\p{L}\\p{N} _.-]"), "").trim().take(80).ifEmpty { id }
            val file = File(dir, "$safe [$id].${resolved.ext}")
            download(resolved.url, file)
            val dao = AppDb.get(applicationContext).dao()
            if (video) dao.setVideoPath(id, file.absolutePath) else dao.setAudioPath(id, file.absolutePath)
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(workDataOf("err" to (e.message ?: "Bilinmeyen hata")))
        }
    }

    /** YouTube hız sınırlamasını azaltmak için Range ile parça parça indirir. */
    private suspend fun download(url: String, out: File) = withContext(Dispatchers.IO) {
        var start = 0L
        var total = -1L
        var lastPct = -1
        try {
            out.outputStream().use { os ->
                val buf = ByteArray(64 * 1024)
                while (total < 0 || start < total) {
                    val req = okhttp3.Request.Builder().url(url)
                        .header("User-Agent", USER_AGENT)
                        .header("Range", "bytes=$start-${start + CHUNK - 1}")
                        .build()
                    Yt.client.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) error("HTTP ${resp.code}")
                        val body = resp.body ?: error("Boş yanıt")
                        val whole = resp.code == 200 // sunucu Range'i yok saydı
                        if (total < 0) {
                            total = resp.header("Content-Range")?.substringAfter('/')?.toLongOrNull()
                                ?: body.contentLength()
                        }
                        body.byteStream().use { input ->
                            while (true) {
                                ensureActive()
                                val n = input.read(buf)
                                if (n < 0) break
                                os.write(buf, 0, n)
                                start += n
                                if (total > 0) {
                                    val pct = (start * 100 / total).toInt()
                                    if (pct != lastPct) {
                                        lastPct = pct
                                        setProgress(workDataOf(KEY_PROGRESS to pct))
                                    }
                                }
                            }
                        }
                        if (whole) total = start
                    }
                    if (total <= 0) break
                }
            }
        } catch (e: Exception) {
            out.delete()
            throw e
        }
    }

    companion object {
        const val KEY_ID = "id"
        const val KEY_TITLE = "title"
        const val KEY_VIDEO = "video"
        const val KEY_PROGRESS = "p"
        const val TAG = "dl"
        private const val CHANNEL = "downloads"
        private const val CHUNK = 4L * 1024 * 1024
    }
}
