package com.bd.muzik.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFFFF3D3D)
val Bg = Color(0xFF0F0F0F)
val Card = Color(0xFF1C1C1C)

private val scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    background = Bg,
    surface = Bg,
    surfaceVariant = Card,
    onSurface = Color(0xFFF2F2F2),
    onSurfaceVariant = Color(0xFFB0B0B0),
    secondaryContainer = Color(0xFF3A1A1A),
    onSecondaryContainer = Color.White
)

@Composable
fun BdTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
