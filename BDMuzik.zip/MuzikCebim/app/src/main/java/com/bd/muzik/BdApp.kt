package com.bd.muzik

import android.app.Application
import com.bd.muzik.yt.Yt
import kotlin.concurrent.thread

class BdApp : Application() {
    override fun onCreate() {
        super.onCreate()
        thread { Yt.init() }
    }
}
