package com.bd.muzik.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import com.bd.muzik.MainVm
import com.bd.muzik.fmt
import kotlinx.coroutines.delay

/** Çalma konumunu 500 ms'de bir okuyan yardımcı. */
@Composable
private fun rememberPosition(vm: MainVm): Pair<Long, Long> {
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    val c = vm.controller
    LaunchedEffect(c, vm.current) {
        while (c != null) {
            pos = c.currentPosition.coerceAtLeast(0)
            dur = c.duration.coerceAtLeast(0)
            delay(500)
        }
    }
    return pos to dur
}

@Composable
fun MiniPlayer(vm: MainVm, onExpand: () -> Unit) {
    val item = vm.current ?: return
    val (pos, dur) = rememberPosition(vm)
    Column(
        Modifier
            .fillMaxWidth()
            .background(Card)
            .clickable(onClick = onExpand)
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Thumb(item.mediaMetadata.artworkUri, 44.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.mediaMetadata.title?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    item.mediaMetadata.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall
                )
            }
            IconButton(onClick = { vm.togglePlay() }) {
                Icon(if (vm.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Oynat/Duraklat")
            }
            IconButton(onClick = { vm.next() }) { Icon(Icons.Rounded.SkipNext, "Sonraki") }
        }
        LinearProgressIndicator(
            progress = { if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().height(2.dp),
            color = Accent,
            trackColor = Color0
        )
    }
}

private val Color0 = androidx.compose.ui.graphics.Color.Transparent

@Composable
fun FullPlayer(vm: MainVm, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val item = vm.current
    val (pos, dur) = rememberPosition(vm)
    var dragging by remember { mutableStateOf<Float?>(null) }

    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Kapat") }
                Spacer(Modifier.weight(1f))
                Text("BD Müzik", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.width(48.dp))
            }
            Spacer(Modifier.height(16.dp))
            AsyncImage(
                model = item?.mediaMetadata?.artworkUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Card)
            )
            Spacer(Modifier.height(28.dp))
            Text(
                item?.mediaMetadata?.title?.toString() ?: "",
                style = MaterialTheme.typography.titleLarge,
                maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Text(
                item?.mediaMetadata?.artist?.toString() ?: "",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(20.dp))

            val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
            Slider(
                value = dragging ?: frac,
                onValueChange = { dragging = it },
                onValueChangeFinished = {
                    dragging?.let { f -> vm.controller?.seekTo((f * dur).toLong()) }
                    dragging = null
                },
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                val shown = dragging?.let { (it * dur).toLong() } ?: pos
                Text(fmt(shown / 1000), style = MaterialTheme.typography.bodySmall)
                Text(fmt(dur / 1000), style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(12.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.toggleShuffle() }) {
                    Icon(Icons.Rounded.Shuffle, "Karıştır",
                        tint = if (vm.shuffle) Accent else MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { vm.previous() }, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, "Önceki", modifier = Modifier.size(36.dp))
                }
                FilledIconButton(
                    onClick = { vm.togglePlay() },
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Accent)
                ) {
                    Icon(
                        if (vm.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        "Oynat/Duraklat", modifier = Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = { vm.next() }, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipNext, "Sonraki", modifier = Modifier.size(36.dp))
                }
                IconButton(onClick = { vm.cycleRepeat() }) {
                    val on = vm.repeatMode != Player.REPEAT_MODE_OFF
                    Icon(
                        if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        "Tekrarla",
                        tint = if (on) Accent else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
